export {
  default as HomeOutline
} from '@ant-design/icons/lib/outline/HomeOutline'
export {
  default as SlidersOutline
} from '@ant-design/icons/lib/outline/SlidersOutline'
export {
  default as TransactionOutline
} from '@ant-design/icons/lib/outline/TransactionOutline'