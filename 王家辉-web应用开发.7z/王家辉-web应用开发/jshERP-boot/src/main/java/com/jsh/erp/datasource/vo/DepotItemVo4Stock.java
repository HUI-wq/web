package com.jsh.erp.datasource.vo;


import java.math.BigDecimal;

public class DepotItemVo4Stock {

    private BigDecimal inNum;
    private BigDecimal outNum;

    public BigDecimal getInNum() {
        return inNum;
    }

    public void setInNum(BigDecimal inNum) {
        this.inNum = inNum;
    }

    public BigDecimal getOutNum() {
        return outNum;
    }

    public void setOutNum(BigDecimal outNum) {
        this.outNum = outNum;
    }
}
