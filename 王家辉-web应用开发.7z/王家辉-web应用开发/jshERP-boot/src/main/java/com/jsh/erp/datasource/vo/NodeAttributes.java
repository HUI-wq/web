package com.jsh.erp.datasource.vo;

/**
 * Description
 *
 * @Author: qiankunpingtai
 * @Date: 2019/3/13 18:11
 */
public class NodeAttributes {
    //编号
    private String no;
    //类型
    private Integer type;

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
}
