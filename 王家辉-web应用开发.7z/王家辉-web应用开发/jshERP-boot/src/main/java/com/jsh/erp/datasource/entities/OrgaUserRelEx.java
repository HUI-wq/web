package com.jsh.erp.datasource.entities;

/**
 * Description
 *
 * @Author: cjl
 * @Date: 2019/3/12 10:09
 */
public class OrgaUserRelEx extends OrgaUserRel {
}
